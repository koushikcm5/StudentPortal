package firstsample.demo.Model;
public enum Role {
    USER,
    ADMIN
}
