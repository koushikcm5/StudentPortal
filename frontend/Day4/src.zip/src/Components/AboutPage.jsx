import './AboutPage.css'; 
import NavBar from './NavBar';
function AboutPage() {
    return (
        <div className="about-container"> 
        <NavBar/>
            <h1>About Student Assistance Portal</h1>
            <p>Welcome to the Student Assistance Portal! We are dedicated to providing assistance and support to students in their educational journey.</p>
            <p>Our mission is to make the process of seeking information, guidance, and assistance easy and accessible for students.</p>
            <p>Whether you are looking for resources, have questions, or need help with anything related to your education, we are here to assist you every step of the way.</p>
            <p>Feel free to explore our portal, and if you have any inquiries or need assistance, do not hesitate to reach out to us.</p>
            <div className="image-container">
                <img src="https://img.freepik.com/free-photo/online-communication_1098-15842.jpg?w=996" alt="Image 1" className="about-image" />
                <img src="https://img.freepik.com/free-photo/graduation-commemorating-commemorating-successful-concept_1142-58743.jpg?t=st=1708670393~exp=1708673993~hmac=348889b56f40612db4694a7beb5e33eb46b98d5d7a52cf7c6975a2e996622829&w=740" alt="Image 2" className="about-image" />
            </div>
        </div>
    );
}

export default AboutPage;
