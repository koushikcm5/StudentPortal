import NavBar from './NavBar';
import './Profile.css';
import { Link } from 'react-router-dom'; // Import Link from react-router-dom

function Profile() {
    const handleLogout = () => {
        // Implement logout functionality here
        // For example: Clear local storage, reset state, etc.
        console.log("Logout"); // Placeholder for logout functionality
    };

    return (
        <div className="profile">
            <NavBar/>
            <img src="https://img.freepik.com/free-psd/3d-illustration-human-avatar-profile_23-2150671142.jpg?t=st=1708746961~exp=1708750561~hmac=7c7d20ac35c6799439724cfee1b66fdcd65a49998094ee052fef440d06d48332&w=740" alt="Profile" className="profile-image" />
            <h2>User Profile</h2>
            <div className="profile-info">
                <p>Name: Koushik</p>
                <p>Email: koushik@gmail.com</p>
                <p>Location: coimbatore</p>
                {/* Add logout button */}
                <Link to="/"> <button onClick={handleLogout}>Logout</button></Link>
              
            </div>
        </div>
    );
}

export default Profile;
