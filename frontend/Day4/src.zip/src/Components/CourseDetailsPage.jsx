

import { useState } from 'react';
import { Link } from 'react-router-dom';
import PaymentPage from './PaymentPage';
import './CourseDetailsPage.css';
import NavBar from './NavBar';

const courses = [
  {
    id: 1,
    title: "Introduction to Programming",
    description: "Learn the basics of programming with this introductory course.",
    duration: "8 weeks",
    cost: "Rs:5000",
    image: "https://img.freepik.com/free-photo/learning-education-ideas-insight-intelligence-study-concept_53876-120116.jpg?w=1380&t=st=1708681971~exp=1708682571~hmac=5b2c5a3e7cea7f9b48bbe9ccd962d1f60f17550b1a8d160ac3838b68e6842e0d"
  },
  {
    id: 2,
    title: "Web Development Bootcamp",
    description: "Master the art of building modern websites and web applications.",
    duration: "12 weeks",
    cost: "Rs:8000",
    image: "https://img.freepik.com/free-photo/here-s-my-results-group-young-people-casual-clothes-working-modern-office_146671-16517.jpg?t=st=1708684636~exp=1708688236~hmac=b092d6eedf4295e8dcc4e9648a6efdbfc1db951c5d7c1d73d89d6d162dd3fcc4&w=996"
  },
  {
    id: 3,
    title: "Data Science Fundamentals",
    description: "Unlock the power of data with this comprehensive course on data science fundamentals.",
    duration: "10 weeks",
    cost: "Rs:7000",
    image: "https://img.freepik.com/free-vector/students-using-e-learning-platform-video-laptop-graduation-cap-online-education-platform-e-learning-platform-online-teaching-concept_335657-795.jpg?t=st=1708684690~exp=1708688290~hmac=eec80c8ed243ecfbdff0bbc0b09d67f95666eccf3155ed465ca76135192a543b&w=996"
  },
  {
    id: 4,
    title: "Machine Learning Mastery",
    description: "Dive deep into machine learning algorithms and techniques with hands-on projects.",
    duration: "14 weeks",
    cost: "Rs:10000",
    image: "https://img.freepik.com/free-vector/machine-learning-isometric-composition-with-text-cubes-with-code-robotic-head-chip-with-academic-hat-vector-illustration_1284-82015.jpg?t=st=1708684733~exp=1708688333~hmac=eea322f1cca2198ad272658a736e854bae7d94aa68e837d6f7dd09946c3d47d9&w=740"
  },
  {
    id: 5,
    title: "Mobile App Development",
    description: "Build your own mobile apps for iOS and Android platforms from scratch.",
    duration: "16 weeks",
    cost: "Rs:9000",
    image: "https://img.freepik.com/free-vector/e-learning-education-process-training-application-mobile-app-development-courses-mobile-apps-online-courses-become-mobile-developer-concept_335657-202.jpg?t=st=1708684818~exp=1708688418~hmac=ecdde04cc157579fafbb0bc281f2eec011b8a40c562e1653862ba819e81e0f21&w=996"
  },
  {
    id: 6,
    title: "Cybersecurity Essentials",
    description: "Learn the essentials of cybersecurity to protect yourself and your organization.",
    duration: "8 weeks",
    cost: "Rs:6000",
    image: "https://img.freepik.com/free-photo/cyber-security-protection-firewall-interface-concept_53876-123929.jpg?t=st=1708684867~exp=1708688467~hmac=5b7dcc01e8a7c798ef062e2f8a4cbe218de3cb38a850976d3cc54531f855cc66&w=1060"
  },
];

function CourseDetailsPage() {
  const [selectedCourse, setSelectedCourse] = useState(null);

  const handleAddToCart = (title) => {
    alert(`"${title}" added to cart!`);
  };

  // const handlePayNow = (course) => {
  //   setSelectedCourse(course);
  // };

  const handleClosePayment = () => {
    setSelectedCourse(null);
  };

  return (
    <div className="course-container">
      <NavBar/>
      <h1 id='c1'>Available Course</h1>
      {courses.map(course => (
        <div key={course.id} className="course-card">
          <img src={course.image} alt={course.title} />
          <h3>{course.title}</h3>
          <p>{course.description}</p>
          <p><strong>Duration:</strong> {course.duration}</p>
          <p><strong>Cost:</strong> {course.cost}</p>
          <div className="button-group">
            <button className="add-to-cart" onClick={() => handleAddToCart(course.title)}>Add to Cart</button>
          <Link to='/pay'><button className="pay-now" >Pay Now</button></Link>
          </div>
        </div>
      ))}
      {selectedCourse && <PaymentPage course={selectedCourse} onClose={handleClosePayment} />}
    </div>
  );
}

export default CourseDetailsPage;
