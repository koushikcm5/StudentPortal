
import  { useState } from 'react';
import NavBar from './NavBar';

function PaymentPage() {
  const [paymentInfo, setPaymentInfo] = useState({
    name: '',
    cardNumber: '',
    expiryDate: '',
    cvv: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPaymentInfo(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handlePayment = (e) => {
    e.preventDefault(); // Prevent form submission
    // Add your payment processing logic here
    alert(`Payment processed for "${paymentInfo.name}"!`);
    // Clear the form fields after processing payment
    setPaymentInfo({
      name: '',
      cardNumber: '',
      expiryDate: '',
      cvv: ''
    });
  };

  return (
    <div className="payment-container">
      <NavBar/>
      <h2>Payment Details for Introduction to Programming</h2>
      <form onSubmit={handlePayment}>
        <div className="form-group">
          <label>Name on Card:</label>
          <input type="text" name="name" value={paymentInfo.name} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
          <label>Card Number:</label>
          <input type="text" name="cardNumber" value={paymentInfo.cardNumber} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
          <label>Expiry Date:</label>
          <input type="text" name="expiryDate" value={paymentInfo.expiryDate} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
          <label>CVV:</label>
          <input type="text" name="cvv" value={paymentInfo.cvv} onChange={handleInputChange} required />
        </div>
        <button type="submit">Pay Now</button>
      </form>
    </div>
  );
}

export default PaymentPage;









// import  { useState } from 'react';

// function PaymentPage({ course }) {
//   const [paymentInfo, setPaymentInfo] = useState({
//     name: '',
//     cardNumber: '',
//     expiryDate: '',
//     cvv: ''
//   });

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setPaymentInfo(prevState => ({
//       ...prevState,
//       [name]: value
//     }));
//   };

//   const handlePayment = () => {
//     // Add your payment processing logic here
//     alert(`Payment processed for "${course.title}"!`);
//     onClose(); // Close the payment modal
//   };

//   return (
//     <div className="payment-container">
//       <h2>Payment Details for {course.title}</h2>
//       <form onSubmit={handlePayment}>
//         <div className="form-group">
//           <label>Name on Card:</label>
//           <input type="text" name="name" value={paymentInfo.name} onChange={handleInputChange} required />
//         </div>
//         <div className="form-group">
//           <label>Card Number:</label>
//           <input type="text" name="cardNumber" value={paymentInfo.cardNumber} onChange={handleInputChange} required />
//         </div>
//         <div className="form-group">
//           <label>Expiry Date:</label>
//           <input type="text" name="expiryDate" value={paymentInfo.expiryDate} onChange={handleInputChange} required />
//         </div>
//         <div className="form-group">
//           <label>CVV:</label>
//           <input type="text" name="cvv" value={paymentInfo.cvv} onChange={handleInputChange} required />
//         </div>
//         <button type="submit">Pay Now</button>
//       </form>
//     </div>
//   );
// }

// export default PaymentPage;
