// import { Link } from 'react-router-dom';
// import './NavBar.css'; 

// function NavBar() {
//     return (
//         <nav className="navbar">
//             <div className="logo">
//                 <Link to="/home">Student Assistance Portal</Link>
//             </div>
//             <ul className="nav-links">
//                 <li>
//                     <Link to="/home">Home</Link>
//                 </li>
//                 <li>
//                     <Link to="/about">About</Link>
//                 </li>
//                 <li>
//                     <Link to="/services">Services</Link>
//                 </li>
//                 <li>
//                     <Link to="/contact">Contact</Link>
//                 </li>
//                 <li>
//                     <Link to="/faq">FAQ</Link> {/* Added FAQ link */}
//                 </li>
//                 <li>
//                     <Link to="/">Login</Link>
//                 </li>
//                 <li>
//                     <Link to="/register">Register</Link>
//                 </li>
//             </ul>
//         </nav>
//     );
// }

// export default NavBar;
import { Link } from 'react-router-dom';
import './NavBar.css'; 

function NavBar() {
    return (
        <nav className="navbar">
           <div className="logos">
                <Link to="/home">
                    <img src="https://img.freepik.com/free-vector/frame-with-student-boy-reading-book_25030-39072.jpg?t=st=1708704491~exp=1708708091~hmac=13cf47de5537b01e6d4e03650cfd523b8163fa804df182573bd738724ac9ffe9&w=740" alt="Profile Logo" className="profile-logo" />
                </Link>
            </div>
            <h3>Student Enquiry Assistance Portal</h3>
            <ul className="nav-links">
                <li>
                    <Link to="/home">Home</Link>
                </li>
                <li>
                    <Link to="/about">About</Link>
                </li>
                {/* <li>
                    <Link to="/services">Services</Link>
                </li> */}
                <li>
                    <Link to="/contact">Enquiry</Link>
                </li>
                {/* <li>
                    <Link to="/faq">FAQ</Link>
                </li> */}
                <li>
                    <Link to="/enquiry">Courses</Link> 
                </li>
                <li>
                    <Link to="/">Login</Link>
                </li>
                <li>
    <Link to="/profile">
        <img src="https://img.freepik.com/premium-vector/person-icon_109161-4679.jpg?w=740" alt="Profile" className="profile-logo" />
    </Link>
</li>

            </ul>
            
        </nav>
    );
}

export default NavBar;

