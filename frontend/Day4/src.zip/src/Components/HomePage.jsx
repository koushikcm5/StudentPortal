import { Link } from 'react-router-dom';
import './HomePage.css';
import NavBar from './NavBar';

function HomePage() {
    return (
        <div className="home-container">
            <NavBar/>
            <header>
                <h1>Welcome to the Student Assistance Portal</h1>
            </header>
            <main>
                <section className="hero">
                    <h2>Get the help you need</h2>
                    <p>Whether you have questions about courses, registration, or any other aspect of student life, were here to assist you.</p>
                    <Link to="/courses" className="view-all-courses-btn">Get Started</Link> 
                </section>
                <h2>Our Services</h2>
                <section className="features">
                    <div className="feature-card">
                        <h3>Course Information</h3>
                        <p>Find details about available courses, prerequisites, and schedules.</p>
                    </div>
                    <div className="feature-card">
                        <h3>Registration Assistance</h3>
                        <p>Get help with course registration, add/drop deadlines, and enrollment issues.</p>
                    </div>
                    <div className="feature-card">
                        <h3>Student Support</h3>
                        <p>Access resources for academic advising, counseling, and student services.</p>
                    </div>
                </section>
                    <h2> Featured College Courses</h2>
                <section className="college-courses">
                    <div className="course-card">
                        <h3>Computer Science Course</h3>
                        <p>An introductory course covering the basics of computer science.</p>
                    </div>
                    <div className="course-card">
                        <h3>English Literature Survey</h3>
                        <p>Explore major works of English literature from different time periods.</p>
                    </div>
                    <div className="course-card">
                        <h3>Introduction to Psychology</h3>
                        <p>Learn about the basic concepts and theories in psychology.</p>
                    </div>
                </section>
            </main>
            <footer className="expanded-footer">
                <div className="footer-content">
                    <div className="footer-section">
                        <h3>About Us</h3>
                        <p>Learn more about our Student Assistance Portal and how we can help you succeed in your academic journey.</p>
                    </div>
                    <div className="footer-section">
                        <h3>Quick Links</h3>
                        <ul>
                            <li><Link to="/about">About</Link></li>
                            <li><Link to="/contact">Contact Us</Link></li>
                            <li><Link to="/profile">Profile</Link></li>
                        </ul>
                    </div>
                    <div className="footer-section">
                        <h3>Follow Us</h3>
                        <ul>
                            <li><a href="https://twitter.com/studentportal" target="_blank" rel="noopener noreferrer">Twitter</a></li>
                            <li><a href="https://facebook.com/studentportal" target="_blank" rel="noopener noreferrer">Facebook</a></li>
                            <li><a href="https://instagram.com/studentportal" target="_blank" rel="noopener noreferrer">Instagram</a></li>
                        </ul>
                    </div>
                </div>
                <div className="footer-bottom">
                    <p>&copy; Student Assistance Portal</p>
                </div>
            </footer>
        </div>
    );
}

export default HomePage;
