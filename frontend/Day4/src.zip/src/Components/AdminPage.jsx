import  { useState } from 'react';
import './AdminPage.css';
import NavBar from './NavBar';

function AdminPage() {
    const [courses, setCourses] = useState([
        { id: 1, title: "Introduction to React", description: "Learn the basics of React.js framework.", image: "https://img.freepik.com/free-vector/react-native-mobile-app-abstract-concept-illustration-cross-platform-native-mobile-app-development-framework-javascript-library-user-interface-operating-system_335657-3350.jpg?t=st=1708768851~exp=1708772451~hmac=37daebda9916b7662c29c76d171416487c6cd5884de3c1d4c2128946733838be&w=740" },
        { id: 2, title: "Node.js Development", description: "Master backend development with Node.js.", image: "https://img.freepik.com/free-vector/programmers-using-javascript-programming-language-computer-tiny-people-javascript-language-javascript-engine-js-web-development-concept-bright-vibrant-violet-isolated-illustration_335657-986.jpg?t=st=1708768900~exp=1708772500~hmac=094ace3fded8aeca365db343140758c5cc68c062104db62a4f1fa60131f098b3&w=996" },
        { id: 3, title: "Full-Stack Web Development", description: "Learn both frontend and backend development.", image: "https://img.freepik.com/free-photo/person-front-computer-working-html_23-2150040428.jpg?t=st=1708768959~exp=1708772559~hmac=164511908b5d65796401e3795a8aef00521504cfd6fc2d5825283eef68e6bcbc&w=996" }
    ]);

    const [newCourse, setNewCourse] = useState({ title: "", description: "" });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setNewCourse(prevState => ({
            ...prevState,
            [name]: value
        }));
    };

    const addCourse = () => {
        const id = courses.length + 1;
        setCourses([...courses, { ...newCourse, id }]);
        setNewCourse({ title: "", description: "" });
    };

    const deleteCourse = (id) => {
        setCourses(courses.filter(course => course.id !== id));
    };

    return (
        <div className="admin-container">
            <NavBar />
            <h1>Admin Dashboard</h1>
            <h2>Add New Course</h2>
            <input
                type="text"
                name="title"
                placeholder="Title"
                value={newCourse.title}
                onChange={handleChange}
            />
            <textarea
                name="description"
                placeholder="Description"
                value={newCourse.description}
                onChange={handleChange}
            />
            {/* <input
                type="text"
                name="image"
                placeholder="Image URL"
                value={newCourse.image}
                onChange={handleChange}
            /> */}
            <button onClick={addCourse}>Add Course</button>

            <h2>Courses</h2>
            <ul>
                {courses.map(course => (
                    <li key={course.id}>
                        <h3>{course.title}</h3>
                        <img src={course.image} alt={course.title} />
                        <p>{course.description}</p>
                        <button onClick={() => deleteCourse(course.id)}>Delete</button>
                        
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default AdminPage;
