
import { Link } from 'react-router-dom';
import './EnquiryPage.css';
import NavBar from './NavBar';

function EnquiryPage() {
    
    const courses = [
        {
            id: 1,
            title: "Introduction to Programming",
            description: "Learn the basics of programming with this introductory course.",
            duration: "8 weeks"
        },
        {
            id: 2,
            title: "Web Development Fundamentals",
            description: "Get started with web development by learning HTML, CSS, and JavaScript.",
            duration: "10 weeks"
        },
        {
            id: 3,
            title: "Data Science Essentials",
            description: "Explore the fundamentals of data science, including data analysis and visualization.",
            duration: "12 weeks"
        },
        // Add more courses here
        {
            id: 4,
            title: "Machine Learning Basics",
            description: "Learn the basics of machine learning algorithms and techniques.",
            duration: "10 weeks"
        },
        {
            id: 5,
            title: "Full-Stack Web Development",
            description: "Master both front-end and back-end development to become a full-stack developer.",
            duration: "16 weeks"
        }
    ];

    return (
        
        <div className="enquiry-container">
            <NavBar/>
            <h1 className="enquiry-heading">Course Service</h1>
            <p>Welcome to the Enquiry Service page!</p>
            <h2>Featured Courses</h2>
            <ul className="course-list">
                {courses.map(course => (
                    <li key={course.id} className="course-item">
                        <h3 className="course-title">{course.title}</h3>
                        <p className="course-description">{course.description}</p>
                        <p className="course-duration"><strong>Duration:</strong> {course.duration}</p>
                        <Link to={`/courses/${course.id}`} className="view-course-details-btn">View Details</Link>
                    </li>
                ))}
            </ul>
            <Link to="/courses" className="view-all-courses-btn">View All Courses</Link> 
        </div>
    );
}

export default EnquiryPage;
