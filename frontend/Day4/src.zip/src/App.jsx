// // import { useState } from 'react'
// // import reactLogo from './assets/react.svg'
// // import viteLogo from '/vite.svg'
// import './App.css'
// // import './LoginPage.js'
// import LoginPage from './Components/LoginPage.jsx'
// import { BrowserRouter, Route, Routes } from 'react-router-dom'
// import RegistrationPage from './Components/RegistrationPage.jsx'
// function App() {
// return (
   
//     <BrowserRouter>
//     <Routes>
//       <Route path='/' element={<LoginPage/>} />
//       <Route path='/register' element={<RegistrationPage/>} />
//       </Routes>
//       </BrowserRouter>
      
//   )
// }

// export default App

// import { BrowserRouter, Route, Routes } from 'react-router-dom';
// import './App.css';
// import LoginPage from './Components/LoginPage.jsx';
// import RegistrationPage from './Components/RegistrationPage.jsx';
// import NavBar from './Components/NavBar.jsx';
// import HomePage from './Components/HomePage.jsx';

// function App() {
//   return (
//     <BrowserRouter>
//       <NavBar />
//       <Routes>
//         <Route path="/" element={<LoginPage />} />
//         <Route path="/home" element={<HomePage />} />
//         <Route path="/register" element={<RegistrationPage />} />
//       </Routes>
//     </BrowserRouter>
//   );
// }

import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import LoginPage from './Components/LoginPage.jsx';
// import NavBar from './Components/NavBar.jsx';
import HomePage from './Components/HomePage.jsx';
import EnquiryPage from './Components/EnquiryPage.jsx'; 
import AboutPage from './Components/AboutPage.jsx';
import ContactPage from './Components/ContactPage.jsx';
import CourseDetailsPage from './Components/CourseDetailsPage.jsx';
import Profile from './Components/Profile.jsx';
import RegistrationPage from './Components/RegistrationPage.jsx';
import AdminPage from './Components/AdminPage.jsx';
import PaymentPage from './Components/PaymentPage.jsx';
import AdminLoginPage from './Components/AdminLoginPage.jsx';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/register" element={<RegistrationPage/>} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/profile" element={<Profile/>} />
        <Route path="/enquiry" element={<EnquiryPage />} /> 
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/courses" element={<CourseDetailsPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/pay" element={<PaymentPage />} />
        <Route path="/adminlogin" element={<AdminLoginPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

